<template>
  <v-layout>
    <v-flex class="text-center">
      orders
    </v-flex>
  </v-layout>
</template>
