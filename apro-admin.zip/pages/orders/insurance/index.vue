<template>
  <v-layout>
    <v-flex class="text-center">
      insurance
    </v-flex>
  </v-layout>
</template>
