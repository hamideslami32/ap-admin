<template>
  <v-layout>
    <v-flex class="text-center">
      hotel
    </v-flex>
  </v-layout>
</template>
